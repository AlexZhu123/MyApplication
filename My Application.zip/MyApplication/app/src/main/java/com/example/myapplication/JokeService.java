package com.example.myapplication;

import retrofit2.Call;
import retrofit2.http.GET;

public interface JokeService {
    @GET("/jokeapi/v2/joke/Any")
    Call<Joke> getJoke();
}
